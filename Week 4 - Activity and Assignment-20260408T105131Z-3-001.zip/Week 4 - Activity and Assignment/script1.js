document.getElementById("myForm").addEventListener("submit", function(event){

event.preventDefault(); // 🚨 THIS stops the refresh

let name = document.getElementById("name").value;
let email = document.getElementById("email").value;
let password = document.getElementById("password").value;

let error = document.getElementById("error");

if(name === "" || email === "" || password === ""){
error.innerHTML = "All fields are required!";
return;
}

if(password.length < 6){
error.innerHTML = "Password must be at least 6 characters.";
return;
}

error.innerHTML = "";
alert("Form submitted successfully!");

});