let user = {
name: "Mouna",
age: 21,
city: "Bengaluru"
};

function showUser(){

document.getElementById("name").innerHTML = "Name: " + user.name;

document.getElementById("age").innerHTML = "Age: " + user.age;

document.getElementById("city").innerHTML = "City: " + user.city;

}