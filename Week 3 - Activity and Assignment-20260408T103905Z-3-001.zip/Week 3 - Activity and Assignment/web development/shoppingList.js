let shoppingList = [];

// Add items
shoppingList.push("Milk");
shoppingList.push("Bread");
shoppingList.push("Eggs");

console.log("Shopping List:", shoppingList);

// Remove last item
shoppingList.pop();

console.log("After removing last item:", shoppingList);